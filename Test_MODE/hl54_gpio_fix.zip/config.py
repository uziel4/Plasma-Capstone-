# ============================================================
# config.py
# Archivo central de configuración del sistema.
# HL-54 Relay Board por GPIO directo.
#
# Conexiones:
# Relay lógico 1 = GPIO 17 = Pin físico 11 = IN1 = Mechanical Roughing Pump
# Relay lógico 2 = GPIO 22 = Pin físico 15 = IN3 = Gas Mass Control Solenoid Valve
#
# IMPORTANTE:
# HL-54 normalmente es ACTIVE LOW:
# GPIO LOW  = Relay ON
# GPIO HIGH = Relay OFF
# ============================================================

APP_TITLE = "PUPR PLASMA MOBILE REACTOR VACUUM CONTROLLER VER. 2.0"

# ============================================================
# TEST MODE
# ============================================================
# "AUTO"  = intenta usar hardware real; si falla, usa simulación
# True    = fuerza simulación siempre
# False   = fuerza hardware real
# ============================================================
TEST_MODE = "AUTO"

# ============================================================
# DAQC2plate
# ============================================================
DAQC2_ADDRESS = 0
DAQC2_CHANNEL = 0

# ============================================================
# HL-54 Relay Board - GPIO directo
# ============================================================
RELAY_ACTIVE_LOW = True

ROUGHING_GPIO = 17
MASS_FLOW_GPIO = 22

# Compatibilidad con gui.py
# NO son relays I2C. Son IDs lógicos internos.
ROUGHING_RELAY = 1
MASS_FLOW_RELAY = 2

# Se dejan para que gui.py no falle si los importa.
# El HL-54 no usa I2C.
RELAY_I2C_BUS = None
RELAY_I2C_ADDRESS = None

# ============================================================
# Control tuning
# ============================================================
VACUUM_TOLERANCE = 0.05

# ============================================================
# Seguridad visual / simulación
# ============================================================
SIM_INITIAL_TORR = 1.450e-1

# ============================================================
# Colores del GUI
# ============================================================
COLORS = {
    "background": "#050814",
    "panel": "#0b1220",
    "panel_light": "#111827",
    "panel_soft": "#162033",

    "button": "#1d4ed8",
    "button_hover": "#2563eb",
    "button_active": "#dc2626",

    "white": "#f8fafc",
    "muted": "#94a3b8",
    "input": "#e0f2fe",
    "black": "#020617",

    "red": "#ef4444",
    "green": "#22c55e",
    "yellow": "#facc15",
    "gray": "#64748b",

    "grid": "#334155",
    "graph_line": "#38bdf8",
    "graph_marker": "#f8fafc",
}
