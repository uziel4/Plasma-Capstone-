# ============================================================
# relay_controller.py
# Controlador NUEVO para HL-54 Relay Board usando GPIO directo.
#
# Este board NO usa I2C.
#
# Conexiones físicas:
# GPIO 17 | Pin físico 11 | IN1 | Mechanical Roughing Pump
# GPIO 22 | Pin físico 15 | IN3 | Gas Mass Control Solenoid Valve
#
# Mapeo usado por gui.py:
# Relay lógico 1 -> GPIO 17 -> IN1 -> Mechanical Roughing Pump
# Relay lógico 2 -> GPIO 22 -> IN3 -> Gas Mass Control Solenoid Valve
#
# HL-54 normalmente trabaja ACTIVE LOW:
# GPIO LOW  = Relay ON
# GPIO HIGH = Relay OFF
# ============================================================

import time

from config import (
    RELAY_ACTIVE_LOW,
    ROUGHING_GPIO,
    MASS_FLOW_GPIO,
)


class RelayController:
    def __init__(self, bus_number=None, address=None, test_mode="AUTO"):
        # Estos parámetros se aceptan solo para que gui.py no falle.
        # El HL-54 NO usa I2C.
        self.bus_number = bus_number
        self.address = address
        self.test_mode = test_mode

        self.active_low = RELAY_ACTIVE_LOW
        self.simulated = False
        self.gpio = None

        # Relay lógico usado por gui.py -> GPIO real del Raspberry Pi
        self.relay_pins = {
            1: ROUGHING_GPIO,    # IN1 - Mechanical Roughing Pump
            2: MASS_FLOW_GPIO,   # IN3 - Gas Mass Control Solenoid Valve
        }

        # Estado interno: False = OFF, True = ON
        self.relay_states = {
            1: False,
            2: False,
        }

        self._initialize_hardware()

    def _initialize_hardware(self):
        if self.test_mode is True:
            self.simulated = True
            return

        try:
            import RPi.GPIO as GPIO

            self.gpio = GPIO
            self.gpio.setmode(GPIO.BCM)
            self.gpio.setwarnings(False)

            # Inicializar ambos relays apagados desde el arranque
            off_level = self._gpio_level(False)

            for gpio_pin in self.relay_pins.values():
                self.gpio.setup(gpio_pin, self.gpio.OUT, initial=off_level)

            time.sleep(0.1)
            self.simulated = False
            self.all_off()

        except Exception:
            if self.test_mode == "AUTO":
                self.simulated = True
            else:
                raise

    def _gpio_level(self, state):
        """
        state=True  -> Relay ON
        state=False -> Relay OFF
        """
        if self.active_low:
            return 0 if state else 1

        return 1 if state else 0

    def relay_on(self, relay_number):
        self.set_relay(relay_number, True)

    def relay_off(self, relay_number):
        self.set_relay(relay_number, False)

    def set_relay(self, relay_number, state):
        """
        relay_number:
            1 = GPIO 17 / Pin 11 / IN1 / Mechanical Roughing Pump
            2 = GPIO 22 / Pin 15 / IN3 / Gas Mass Control Solenoid Valve

        state:
            True  = ON
            False = OFF
        """

        if relay_number not in self.relay_pins:
            return

        state = bool(state)
        self.relay_states[relay_number] = state

        if self.simulated:
            return

        gpio_pin = self.relay_pins[relay_number]
        self.gpio.output(gpio_pin, self._gpio_level(state))

    def all_off(self):
        for relay_number in self.relay_pins:
            self.set_relay(relay_number, False)

    def close(self):
        self.all_off()

        if self.gpio is not None and not self.simulated:
            self.gpio.cleanup(list(self.relay_pins.values()))
